#pragma once

#define HTTP_SERVER "115.76.19.84"
#define HTTP_PORT 80

#define TFTP_SERVER "115.76.19.84"
